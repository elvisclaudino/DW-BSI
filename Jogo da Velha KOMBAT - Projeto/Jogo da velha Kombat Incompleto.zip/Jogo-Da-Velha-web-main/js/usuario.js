var usuariojs = document.querySelector("#usuario");


console.log(usuariojs)


var tittle = document.querySelector("#titulo")

console.log(tittle)